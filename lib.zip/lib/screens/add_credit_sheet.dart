import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../database_helper.dart';
import '../models.dart';
import '../utils/helpers.dart';

class AddChequeSheet extends StatefulWidget {
  final int clientId;  // هذا هو الصحيح
  final VoidCallback onSaved;
  const AddChequeSheet({super.key, required this.clientId, required this.onSaved});

  @override
  State<AddChequeSheet> createState() => _AddChequeSheetState();
}

class _AddChequeSheetState extends State<AddChequeSheet> {
  final _numeroCtrl = TextEditingController();
  final _montantCtrl = TextEditingController();
  final _banqueCtrl = TextEditingController();
  final _dateCtrl = TextEditingController();
  String? _imagePath;
  bool _saving = false;

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => _imagePath = picked.path);
    }
  }

  Future<void> _takePhoto() async {
    final ImagePicker picker = ImagePicker();
    final XFile? picked = await picker.pickImage(source: ImageSource.camera);
    if (picked != null) {
      setState(() => _imagePath = picked.path);
    }
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date != null) {
      _dateCtrl.text = '${date.day}/${date.month}/${date.year}';
    }
  }

  Widget _buildThumbnail() {
    if (_imagePath == null) return const SizedBox.shrink();
    
    return GestureDetector(
      onTap: () => _showFullImage(),
      child: Container(
        margin: const EdgeInsets.only(top: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF1B8A6B), width: 2),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.file(
            File(_imagePath!),
            height: 80,
            width: 80,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  void _showFullImage() {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.black,
        child: GestureDetector(
          onTap: () => Navigator.pop(ctx),
          child: InteractiveViewer(
            panEnabled: true,
            scaleEnabled: true,
            child: Image.file(
              File(_imagePath!),
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                  const Text(
                    'إضافة شيك',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _numeroCtrl,
                textAlign: TextAlign.right,
                decoration: const InputDecoration(
                  hintText: 'رقم الشيك *',
                  hintStyle: TextStyle(fontFamily: 'Cairo'),
                  filled: true,
                  fillColor: Color(0xFFF5F6FA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _montantCtrl,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.right,
                decoration: const InputDecoration(
                  hintText: 'المبلغ *',
                  hintStyle: TextStyle(fontFamily: 'Cairo'),
                  prefixText: 'درهم  ',
                  filled: true,
                  fillColor: Color(0xFFF5F6FA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _banqueCtrl,
                textAlign: TextAlign.right,
                decoration: const InputDecoration(
                  hintText: 'البنك',
                  hintStyle: TextStyle(fontFamily: 'Cairo'),
                  filled: true,
                  fillColor: Color(0xFFF5F6FA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _dateCtrl,
                readOnly: true,
                onTap: _selectDate,
                textAlign: TextAlign.right,
                decoration: const InputDecoration(
                  hintText: 'تاريخ الاستحقاق *',
                  hintStyle: TextStyle(fontFamily: 'Cairo'),
                  suffixIcon: Icon(Icons.calendar_today),
                  filled: true,
                  fillColor: Color(0xFFF5F6FA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickImage,
                      icon: const Icon(Icons.photo_library),
                      label: const Text('معرض الصور', style: TextStyle(fontFamily: 'Cairo')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _takePhoto,
                      icon: const Icon(Icons.camera_alt),
                      label: const Text('كاميرا', style: TextStyle(fontFamily: 'Cairo')),
                    ),
                  ),
                ],
              ),
              _buildThumbnail(),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1B8A6B),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text(
                          'حفظ الشيك',
                          style: TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'Cairo'),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (_numeroCtrl.text.isEmpty) {
      _showError('رقم الشيك مطلوب');
      return;
    }
    final montant = double.tryParse(_montantCtrl.text.replaceAll(',', '.'));
    if (montant == null || montant <= 0) {
      _showError('دخل مبلغ صحيح');
      return;
    }
    if (_dateCtrl.text.isEmpty) {
      _showError('تاريخ الاستحقاق مطلوب');
      return;
    }

    setState(() => _saving = true);
    
    try {
      final credits = await DatabaseHelper.instance.getCreditsClient(widget.clientId);
      final openCredits = credits.where((c) => !c.estSolde).toList();
      
      if (openCredits.isEmpty) {
        await DatabaseHelper.instance.createCredit(Credit(
          clientId: widget.clientId,
          montantTotal: montant,
          montantRestant: montant,
          dateCredit: DateTime.now(),
          description: 'شيك رقم ${_numeroCtrl.text}',
        ));
        _showSuccess('تم إضافة شيك بقيمة ${formatMontant(montant)}');
      } else {
        await DatabaseHelper.instance.createPaiement(Paiement(
          creditId: openCredits.first.id!,
          montant: montant,
          datePaiement: DateTime.now(),
          note: 'شيك رقم ${_numeroCtrl.text}',
        ));
        _showSuccess('تم إضافة شيك بقيمة ${formatMontant(montant)} كدفعة');
      }
      
      await DatabaseHelper.instance.createCheque(Cheque(
        creditId: widget.clientId,
        numero: _numeroCtrl.text,
        montant: montant,
        dateEcheance: _parseDate(_dateCtrl.text),
        banque: _banqueCtrl.text.isEmpty ? null : _banqueCtrl.text,
        imagePath: _imagePath,
        dateCreation: DateTime.now(),
      ));
      
      widget.onSaved();
      if (mounted) Navigator.pop(context);
    } catch (e) {
      _showError('حدث خطأ: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  DateTime _parseDate(String date) {
    final parts = date.split('/');
    return DateTime(int.parse(parts[2]), int.parse(parts[1]), int.parse(parts[0]));
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message, style: const TextStyle(fontFamily: 'Cairo')), backgroundColor: Colors.red),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message, style: const TextStyle(fontFamily: 'Cairo')), backgroundColor: Colors.green),
    );
  }
}