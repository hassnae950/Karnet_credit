// lib/screens/test_notification_screen.dart
import 'package:flutter/material.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import '../services/notification_service.dart';

class TestNotificationScreen extends StatefulWidget {
  const TestNotificationScreen({super.key});

  @override
  State<TestNotificationScreen> createState() => _TestNotificationScreenState();
}

class _TestNotificationScreenState extends State<TestNotificationScreen> {
  String _status = 'جاهز للاختبار';
  bool _isLoading = false;

  Future<void> _testNotification() async {
    setState(() { _isLoading = true; _status = 'جاري الإرسال...'; });
    try {
      final ok = await NotificationService.instance.requestPermission();
      if (!ok) {
        setState(() { _status = '❌ الإذن مرفوض - فعل الإشعارات من إعدادات التيليفون'; _isLoading = false; });
        return;
      }
      await NotificationService.instance.sendTestNotification();
      setState(() { _status = '✅ سيصلك إشعار بعد دقيقتين!'; _isLoading = false; });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('🔔 انتظر دقيقتين!', style: TextStyle(fontFamily: 'Cairo')),
          backgroundColor: Color(0xFF1B8A6B),
          duration: Duration(seconds: 4),
        ));
      }
    } catch (e) {
      setState(() { _status = '❌ خطأ: $e'; _isLoading = false; });
    }
  }

  Future<void> _checkScheduled() async {
    try {
      final list = await AwesomeNotifications().listScheduledNotifications();
      setState(() { _status = 'إشعارات مجدولة: ${list.length}'; });
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('الإشعارات المجدولة', style: TextStyle(fontFamily: 'Cairo')),
          content: list.isEmpty
              ? const Text('ما كاينش إشعارات مجدولة', style: TextStyle(fontFamily: 'Cairo'))
              : SizedBox(
                  width: double.maxFinite,
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: list.length,
                    itemBuilder: (_, i) => ListTile(
                      leading: const Icon(Icons.notifications_active, color: Color(0xFF1B8A6B)),
                      title: Text(list[i].content?.title ?? 'بدون عنوان',
                          style: const TextStyle(fontFamily: 'Cairo')),
                      subtitle: Text('ID: ${list[i].content?.id}'),
                    ),
                  ),
                ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('حسناً', style: TextStyle(fontFamily: 'Cairo')),
            ),
          ],
        ),
      );
    } catch (e) {
      setState(() { _status = 'خطأ: $e'; });
    }
  }

  Future<void> _cancelAll() async {
    await NotificationService.instance.cancelAll();
    setState(() { _status = '✅ تم حذف جميع الإشعارات'; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🧪 اختبار الإشعارات', style: TextStyle(fontFamily: 'Cairo')),
        backgroundColor: const Color(0xFF1B8A6B),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: const Color(0xFF1B8A6B).withOpacity(0.1),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  const Icon(Icons.notifications_active, size: 48, color: Color(0xFF1B8A6B)),
                  const SizedBox(height: 12),
                  Text(_status,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Cairo')),
                ]),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _testNotification,
              icon: _isLoading
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.send),
              label: const Text('إرسال إشعار تجريبي (دقيقتين)',
                  style: TextStyle(fontSize: 16, fontFamily: 'Cairo')),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1B8A6B),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _checkScheduled,
              icon: const Icon(Icons.list_alt),
              label: const Text('فحص الإشعارات المجدولة', style: TextStyle(fontFamily: 'Cairo')),
              style: OutlinedButton.styleFrom(
                foregroundColor: const Color(0xFF1B8A6B),
                padding: const EdgeInsets.symmetric(vertical: 16),
                side: const BorderSide(color: Color(0xFF1B8A6B)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 12),
            TextButton.icon(
              onPressed: _cancelAll,
              icon: const Icon(Icons.delete_sweep),
              label: const Text('حذف جميع الإشعارات', style: TextStyle(fontFamily: 'Cairo')),
              style: TextButton.styleFrom(
                foregroundColor: Colors.red,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue.withOpacity(0.3)),
              ),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.info_outline, color: Colors.blue),
                  SizedBox(width: 8),
                  Text('تعليمات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Cairo')),
                ]),
                SizedBox(height: 12),
                Text('1️⃣ اضغط "إرسال إشعار تجريبي"', style: TextStyle(fontFamily: 'Cairo')),
                Text('2️⃣ انتظر دقيقتين', style: TextStyle(fontFamily: 'Cairo')),
                Text('3️⃣ إذا وصل الإشعار ✅ = كل شيء يشتغل', style: TextStyle(fontFamily: 'Cairo')),
                Text('4️⃣ إذا ما وصلش ❌ = تحقق من الأذونات', style: TextStyle(fontFamily: 'Cairo')),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}