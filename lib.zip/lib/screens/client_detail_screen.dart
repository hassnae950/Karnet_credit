import 'package:flutter/material.dart';
import '../database_helper.dart';
import '../models.dart';
import 'add_credit_sheet.dart';
import 'add_paiement_sheet.dart';
import 'credit_detail_screen.dart';


// Colors
const kPrimary = Color(0xFF1B8A6B);
const kRed = Color(0xFFD32F2F);
const kGreen = Color(0xFF388E3C);
const kBg = Color(0xFFF5F6FA);
const kRedBg = Color(0xFFFFEBEE);
const kGreenBg = Color(0xFFE8F5E9);

// Helper functions (you should put these in utils/helpers.dart)
String formatMontant(double m) {
  return '${m.toStringAsFixed(2)} درهم';
}

String formatDate(DateTime d) {
  return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}

class ClientDetailScreen extends StatefulWidget {
  final Client client;
  const ClientDetailScreen({super.key, required this.client});

  @override
  State<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends State<ClientDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  List<Credit> _credits = [];
  double _solde = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 1, vsync: this);
    _loadData();
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final credits = await DatabaseHelper.instance.getCreditsClient(widget.client.id!);
    final solde = await DatabaseHelper.instance.getSoldeClient(widget.client.id!);
    setState(() {
      _credits = credits;
      _solde = solde;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kPrimary,
        title: Text(
          widget.client.nom,
          style: const TextStyle(color: Colors.white, fontFamily: 'Cairo'),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        bottom: TabBar(
          controller: _tab,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          labelStyle: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w600),
          tabs: [
            Tab(text: 'الكريديات (${_credits.length})'),
          ],
        ),
      ),
      body: Column(
        children: [
          _soldeCard(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: kPrimary))
                : TabBarView(
                    controller: _tab,
                    children: [
                      _creditsTab(),
                    ],
                  ),
          ),
        ],
      ),
      bottomNavigationBar: _bottomBar(),
    );
  }

  Widget _soldeCard() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
      ),
      child: Column(
        children: [
          const Text(
            'الرصيد',
            style: TextStyle(color: Colors.grey, fontSize: 14, fontFamily: 'Cairo'),
          ),
          const SizedBox(height: 8),
          Text(
            formatMontant(_solde),
            style: TextStyle(
              color: _solde > 0 ? kRed : kGreen,
              fontSize: 28,
              fontWeight: FontWeight.bold,
              fontFamily: 'Cairo',
            ),
          ),
          if (widget.client.telephone != null) ...[
            const SizedBox(height: 6),
            Text(
              widget.client.telephone!,
              style: const TextStyle(color: Colors.grey, fontFamily: 'Cairo'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _creditsTab() {
    if (_credits.isEmpty) {
      return _emptyState(Icons.receipt_long_outlined, 'ما كاين حتى معاملة');
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.separated(
        itemCount: _credits.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => _creditCard(_credits[i]),
      ),
    );
  }

  Widget _creditCard(Credit c) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => CreditDetailScreen(
            credit: c,
            clientNom: widget.client.nom,
          ),
        ),
      ).then((_) => _loadData()),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: c.estSolde ? kGreenBg : kRedBg,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    c.estSolde ? 'مسوى' : 'جاري',
                    style: TextStyle(
                      color: c.estSolde ? kGreen : kRed,
                      fontSize: 11,
                      fontFamily: 'Cairo',
                    ),
                  ),
                ),
                const Spacer(),
                Text(
                  formatDate(c.dateCredit),
                  style: const TextStyle(color: Colors.grey, fontSize: 12, fontFamily: 'Cairo'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      formatMontant(c.montantRestant),
                      style: const TextStyle(
                        color: kRed,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        fontFamily: 'Cairo',
                      ),
                    ),
                    const Text(
                      'الباقي',
                      style: TextStyle(color: Colors.grey, fontSize: 11, fontFamily: 'Cairo'),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      formatMontant(c.montantTotal),
                      style: const TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        fontFamily: 'Cairo',
                      ),
                    ),
                    const Text(
                      'المجموع',
                      style: TextStyle(color: Colors.grey, fontSize: 11, fontFamily: 'Cairo'),
                    ),
                  ],
                ),
              ],
            ),
            if (c.description != null) ...[
              const SizedBox(height: 8),
              Text(
                c.description!,
                style: const TextStyle(color: Colors.grey, fontSize: 12, fontFamily: 'Cairo'),
              ),
            ],
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: c.pourcentagePaye.clamp(0.0, 1.0),
                backgroundColor: kRedBg,
                valueColor: const AlwaysStoppedAnimation<Color>(kPrimary),
                minHeight: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _emptyState(IconData icon, String msg) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 72, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text(
            msg,
            style: const TextStyle(color: Colors.grey, fontSize: 16, fontFamily: 'Cairo'),
          ),
        ],
      ),
    );
  }

  Widget _bottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -2),
          )
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: kRedBg,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _ajouterPaiement,
              icon: const Icon(Icons.arrow_upward, color: kRed),
              label: const Text(
                'أعطيت',
                style: TextStyle(color: kRed, fontFamily: 'Cairo', fontSize: 15),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: kPrimary,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: _ajouterCredit,
              icon: const Icon(Icons.arrow_downward, color: Colors.white),
              label: const Text(
                'أخذت',
                style: TextStyle(color: Colors.white, fontFamily: 'Cairo', fontSize: 15),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _ajouterCredit() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddCreditSheet(clientId: widget.client.id!, onSaved: _loadData),
    );
  }

  void _ajouterPaiement() {
    final open = _credits.where((c) => !c.estSolde).toList();
    if (open.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ما كاين حتى كريدي مفتوح', style: TextStyle(fontFamily: 'Cairo')),
        ),
      );
      return;
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddPaiementSheet(credit: open.first, onSaved: _loadData),
    );
  }
}