// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/onboarding_screen.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'services/app_settings_service.dart';
import 'services/auth_service.dart';
import 'services/notification_service.dart';
import 'utils/app_translations.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppSettingsService.instance.load();
  Tr.setLang(AppSettingsService.instance.lang);

  await NotificationService.instance.init();
  if (AppSettingsService.instance.notificationsOn) {
    final currency = Tr.s('currency');
    await NotificationService.instance.rescheduleAllFromDb(currency);
  }

  runApp(const KarnetApp());
}

class KarnetApp extends StatefulWidget {
  const KarnetApp({super.key});

  @override
  State<KarnetApp> createState() => _KarnetAppState();
}

class _KarnetAppState extends State<KarnetApp> {
  final _svc = AppSettingsService.instance;
  final _authService = AuthService.instance;

  @override
  void initState() {
    super.initState();
    _svc.addListener(_onSettingsChanged);
  }

  @override
  void dispose() {
    _svc.removeListener(_onSettingsChanged);
    super.dispose();
  }

  void _onSettingsChanged() {
    Tr.setLang(_svc.lang);
    setState(() {});
  }

  ThemeMode get _themeMode {
    switch (_svc.themeMode) {
      case 'light': return ThemeMode.light;
      case 'dark':  return ThemeMode.dark;
      default:      return ThemeMode.system;
    }
  }

  ThemeData _buildTheme(Brightness brightness) => ThemeData(
        colorSchemeSeed: const Color(0xFF1B8A6B),
        brightness: brightness,
        fontFamily: 'Cairo',
        cardColor: brightness == Brightness.dark
            ? const Color(0xFF1E1E2E)
            : Colors.white,
        scaffoldBackgroundColor: brightness == Brightness.dark
            ? const Color(0xFF12121A)
            : const Color(0xFFF5F6FA),
        useMaterial3: true,
      );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'كارنيه',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: _buildTheme(Brightness.light),
      darkTheme: _buildTheme(Brightness.dark),
      locale: Tr.locale,
      supportedLocales: const [
        Locale('ar', 'MA'),
        Locale('fr', 'FR'),
        Locale('en', 'US'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(
        textDirection: Tr.textDirection,
        child: child!,
      ),
      home: FutureBuilder<bool>(
        future: _authService.isLoggedIn(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const SplashScreen();
          }
          final isLoggedIn = snapshot.data ?? false;
          if (isLoggedIn) {
            return const HomeScreen();
          } else {
            return const OnboardingScreen();
          }
        },
      ),
      routes: {
        '/home':       (_) => const HomeScreen(),
        '/login':      (_) => const LoginScreen(),
        '/onboarding': (_) => const OnboardingScreen(),
      },
    );
  }
}

// ── Splash Screen ─────────────────────────────────────────────────────────────
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF1B8A6B),
      body: SizedBox.expand(),
    );
  }
}