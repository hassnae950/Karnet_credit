// lib/utils/helpers.dart
import 'package:intl/intl.dart';
import 'app_translations.dart';

String formatMontant(double m) {
  final fmt = NumberFormat('#,##0.00', 'fr_MA');
  final currency = Tr.s('currency');
  final number = fmt.format(m);
  // بلا LRM — نرجعو للتنسيق البسيط
  // الـ textDirection كيتحكم فيه مباشرة فـ pdf_service.dart
  return '$number $currency';
}

String formatDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';