// lib/screens/verification_and_username_screen.dart
// UPDATED WITH AUTO-RESTORE FROM FIRESTORE

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/auth_service.dart';
import '../services/sync_service.dart';
import '../utils/app_translations.dart';
import 'home_screen.dart';

const _kPrimary = Color(0xFF1B8A6B);
const _kRed = Color(0xFFD32F2F);

class VerificationAndUsernameScreen extends StatefulWidget {
  final String phone;
  final SyncService syncService; // ← ADD THIS PARAMETER

  const VerificationAndUsernameScreen({
    super.key,
    required this.phone,
    required this.syncService, // ← ADD THIS
  });

  @override
  State<VerificationAndUsernameScreen> createState() =>
      _VerificationAndUsernameScreenState();
}

class _VerificationAndUsernameScreenState
    extends State<VerificationAndUsernameScreen> {
  final _codeCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  final _authService = AuthService.instance;

  bool _isVerifyingCode = false;
  bool _isLoggingIn = false;
  bool _showUsernameField = false;
  String? _error;

  @override
  void dispose() {
    _codeCtrl.dispose();
    _usernameCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  1. VERIFY OTP CODE
  // ═══════════════════════════════════════════════════════════════════════

  Future<void> _verifyCode() async {
    final code = _codeCtrl.text.trim();

    if (code.isEmpty) {
      setState(() => _error = 'الرجاء إدخال الكود');
      return;
    }

    setState(() {
      _isVerifyingCode = true;
      _error = null;
    });

    try {
      // ✅ Use the CORRECT method name: verifyPhoneCode()
      final success = await _authService.verifyPhoneCode(code);

      if (success && mounted) {
        // Code verified successfully
        setState(() => _showUsernameField = true);
      } else if (mounted) {
        setState(() => _error = 'كود التحقق غير صحيح');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'خطأ في التحقق: $e');
      }
    } finally {
      if (mounted) setState(() => _isVerifyingCode = false);
    }
  }

// ═══════════════════════════════════════════════════════════════════════
//  REPLACE Method 2: _loginAndRestore()
// ═══════════════════════════════════════════════════════════════════════

  // 🔧 FIX: Replace _loginAndRestore() in verification_and_username_screen.dart

  Future<void> _loginAndRestore() async {
    final username = _usernameCtrl.text.trim();
    if (username.isEmpty) {
      setState(() => _error = 'اسم المستخدم مطلوب');
      return;
    }

    setState(() {
      _isLoggingIn = true;
      _error = null;
    });

    try {
      // 1. حاول تسجيل دخول مباشر (مستخدم موجود محلياً)
      bool loginSuccess = await _authService.quickLogin(widget.phone);

      // 2. إذا ما موجودش محلياً — سجلو كجديد
      if (!loginSuccess) {
        loginSuccess = await _authService.completeRegistration(username);
      }

      if (!loginSuccess || !mounted) return;

      // 3. حفظ رقم الهاتف
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_phone', widget.phone);
      await prefs.setBool('is_logged_in', true);

      if (!mounted) return;

      // 4. dialog restore
      _showRestoreDialog();

      // 5. restore من Firebase
      final syncSvc = widget.syncService;
      final hasInternet = await syncSvc.hasInternetConnection();
      bool restored = false;

      if (hasInternet) {
        restored = await syncSvc.restoreAllData(widget.phone);
      }

      if (!mounted) return;
      Navigator.pop(context); // أغلق dialog

      if (restored && syncSvc.syncStatus == Tr.s('restore_success')) {
        _showSuccessSnack('✅ تم استعادة البيانات بنجاح');
      }

      // 6. ← هنا التغيير المهم: HomeScreen جديد كامل
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (route) => false,
      );
    } catch (e) {
      if (mounted) {
        try {
          Navigator.pop(context);
        } catch (_) {}
        setState(() => _error = 'خطأ: $e');
      }
    } finally {
      if (mounted) setState(() => _isLoggingIn = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  UI HELPERS
  // ═══════════════════════════════════════════════════════════════════════

  void _showRestoreDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'جاري تحميل البيانات',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Row(
          children: const [
            CircularProgressIndicator(color: _kPrimary),
            SizedBox(width: 16),
            Expanded(
              child: Text(
                'يرجى الانتظار...',
                style: TextStyle(fontFamily: 'Cairo'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSuccessSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontFamily: 'Cairo'),
        ),
        backgroundColor: Colors.green,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showInfoSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontFamily: 'Cairo'),
        ),
        backgroundColor: Colors.orange,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? const Color(0xFF12121A) : const Color(0xFFF5F6FA);
    final cardBg = isDark ? const Color(0xFF1E1E2E) : Colors.white;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),

              // ── Header ────────────────────────────────────────────────────
              Text(
                _showUsernameField ? 'اسم المستخدم' : 'التحقق من الهاتف',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Cairo',
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
              const SizedBox(height: 12),

              Text(
                _showUsernameField
                    ? 'أدخل اسم مستخدم يسهل تذكره'
                    : 'أدخل الكود المرسل إلى ${widget.phone}',
                style: TextStyle(
                  fontSize: 14,
                  fontFamily: 'Cairo',
                  color: Colors.grey.shade600,
                ),
              ),
              const SizedBox(height: 32),

              // ── Code Verification Field ────────────────────────────────────
              if (!_showUsernameField) ...[
                TextField(
                  controller: _codeCtrl,
                  enabled: !_isVerifyingCode,
                  keyboardType: TextInputType.text,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                  decoration: InputDecoration(
                    hintText: '000000',
                    hintStyle: const TextStyle(
                      fontFamily: 'Cairo',
                      letterSpacing: 4,
                    ),
                    filled: true,
                    fillColor: isDark
                        ? const Color(0xFF2A2A3E)
                        : const Color(0xFFF5F6FA),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 16, horizontal: 16),
                  ),
                ),
              ],

              // ── Username Field ────────────────────────────────────────────
              if (_showUsernameField) ...[
                TextField(
                  controller: _usernameCtrl,
                  enabled: !_isLoggingIn,

                  keyboardType: TextInputType.text, // ← ADD THIS LINE
                  textCapitalization:
                      TextCapitalization.words, // ← اختياري: أول حرف كبير

                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 16,
                    color: isDark ? Colors.white : Colors.black87,
                  ),
                  decoration: InputDecoration(
                    hintText: 'أدخل اسمك أو اسم محلك',
                    hintStyle: const TextStyle(fontFamily: 'Cairo'),
                    prefixIcon:
                        const Icon(Icons.person_outlined, color: _kPrimary),
                    filled: true,
                    fillColor: isDark
                        ? const Color(0xFF2A2A3E)
                        : const Color(0xFFF5F6FA),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 16, horizontal: 16),
                  ),
                ),
              ],

              // ── Error Message ─────────────────────────────────────────────
              if (_error != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _kRed.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: _kRed, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _error!,
                          style: const TextStyle(
                            color: _kRed,
                            fontSize: 13,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: 24),

              // ── Verification Button ────────────────────────────────────────
              if (!_showUsernameField)
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kPrimary,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _isVerifyingCode ? null : _verifyCode,
                    child: _isVerifyingCode
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            'التحقق',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                            ),
                          ),
                  ),
                ),

              // ── Login Button ───────────────────────────────────────────────
              if (_showUsernameField)
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kPrimary,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: _isLoggingIn ? null : _loginAndRestore,
                    child: _isLoggingIn
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            'الدخول',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                            ),
                          ),
                  ),
                ),

              const SizedBox(height: 20),

              // ── Helper Text ────────────────────────────────────────────────
              if (!_showUsernameField)
                Center(
                  child: Text(
                    'لم تستقبل الكود؟',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      color: Colors.grey.shade600,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
