// lib/main.dart
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/pin_lock_screen.dart';
import 'services/app_settings_service.dart';
import 'services/auth_service.dart';
import 'services/notification_service.dart';
import 'utils/app_translations.dart';
import 'firebase_init.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase init مع error handling
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    debugPrint('✅ Firebase initialized');
  } catch (e) {
    debugPrint('⚠️ Firebase init failed: $e');
    // التطبيق يشتغل حتى بدون Firebase
  }

  // Settings
  try {
    await AppSettingsService.instance.load();
    Tr.setLang(AppSettingsService.instance.lang);
  } catch (e) {
    debugPrint('⚠️ Settings load failed: $e');
  }

  // Notifications
  try {
    await NotificationService.instance.init();
    if (AppSettingsService.instance.notificationsOn) {
      await NotificationService.instance
          .rescheduleAllFromDb(Tr.s('currency'));
    }
  } catch (e) {
    debugPrint('⚠️ Notification init failed: $e');
  }

  runApp(const KarnetApp());
}

class KarnetApp extends StatefulWidget {
  const KarnetApp({super.key});
  @override
  State<KarnetApp> createState() => _KarnetAppState();
}

class _KarnetAppState extends State<KarnetApp> {
  final _svc = AppSettingsService.instance;

  @override
  void initState() {
    super.initState();
    _svc.addListener(_onSettingsChanged);
  }

  @override
  void dispose() {
    _svc.removeListener(_onSettingsChanged);
    super.dispose();
  }

  void _onSettingsChanged() {
    Tr.setLang(_svc.lang);
    setState(() {});
  }

  ThemeMode get _themeMode {
    switch (_svc.themeMode) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  ThemeData _buildTheme(Brightness brightness) => ThemeData(
        colorSchemeSeed: const Color(0xFF1B8A6B),
        brightness: brightness,
        fontFamily: 'Cairo',
        cardColor: brightness == Brightness.dark
            ? const Color(0xFF1E1E2E)
            : Colors.white,
        scaffoldBackgroundColor: brightness == Brightness.dark
            ? const Color(0xFF12121A)
            : const Color(0xFFF5F6FA),
        useMaterial3: true,
      );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'كارنيه',
      debugShowCheckedModeBanner: false,
      themeMode: _themeMode,
      theme: _buildTheme(Brightness.light),
      darkTheme: _buildTheme(Brightness.dark),
      locale: Tr.locale,
      supportedLocales: const [
        Locale('ar', 'MA'),
        Locale('fr', 'FR'),
        Locale('en', 'US'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(
        textDirection: Tr.textDirection,
        child: child!,
      ),
      home: const _StartupRouter(),
      routes: {
        '/home': (_) => const HomeScreen(),
        '/login': (_) => const LoginScreen(),
        '/onboarding': (_) => const OnboardingScreen(),
        '/pin-lock': (_) => const PinLockScreen(),
      },
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  STARTUP ROUTER — يحدد الشاشة الأولى تلقائياً
// ═══════════════════════════════════════════════════════════════════════════════
class _StartupRouter extends StatelessWidget {
  const _StartupRouter();

  Future<Widget> _resolveHome() async {
    final prefs = await SharedPreferences.getInstance();

    // ── 1. أول تشغيل؟ → Onboarding ──────────────────────────────────────────
    final seenOnboarding = prefs.getBool('seen_onboarding') ?? false;
    if (!seenOnboarding) {
      await prefs.setBool('seen_onboarding', true);
      return const OnboardingScreen();
    }

    // ── 2. مسجل دخول؟ ────────────────────────────────────────────────────────
    final isLoggedIn = await AuthService.instance.isLoggedIn();
    if (!isLoggedIn) {
      return const LoginScreen();
    }

    // ── 3. PIN مفعّل؟ → شاشة PIN ─────────────────────────────────────────────
    final pinEnabled = prefs.getBool('karnet_pin_enabled') ?? false;
    if (pinEnabled) {
      return const PinLockScreen();
    }

    // ── 4. الافتراضي → HomeScreen ─────────────────────────────────────────────
    return const HomeScreen();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Widget>(
      future: _resolveHome(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _SplashScreen();
        }
        return snapshot.data ?? const LoginScreen();
      },
    );
  }
}

// ── Splash Screen ──────────────────────────────────────────────────────────────
class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF1B8A6B),
      body: Center(
        child: CircularProgressIndicator(color: Colors.white),
      ),
    );
  }
}
