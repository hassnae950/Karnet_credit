// lib/services/sync_service.dart - 100% CLEAN & WORKING
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import '../database_helper.dart';
import '../utils/app_translations.dart';

class SyncService extends ChangeNotifier {
  static final SyncService instance = SyncService._init();
  SyncService._init();

  final FirebaseFirestore _fs = FirebaseFirestore.instance;
  final Connectivity _connectivity = Connectivity();

  bool _isSyncing = false;
  String? _syncStatus;

  bool get isSyncing => _isSyncing;
  String? get syncStatus => _syncStatus;

  // ═══════════════════════════════════════════════════════════════════════════
  //  BACKUP (Push to Firestore)
  // ═══════════════════════════════════════════════════════════════════════════

  Future<bool> backupAllData(String phoneNumber) async {
    if (phoneNumber.isEmpty) {
      _syncStatus = Tr.s('error_invalid_phone');
      notifyListeners();
      return false;
    }

    if (!await hasInternetConnection()) {
      _syncStatus = Tr.s('no_internet_error');
      notifyListeners();
      return false;
    }

    _isSyncing = true;
    _syncStatus = Tr.s('backup_in_progress');
    notifyListeners();

    try {
      final allData = await DatabaseHelper.instance.exportAllData();
      final userDocRef = _fs.collection('users').doc(phoneNumber);
      final batch = _fs.batch();

      if (allData['clients'] != null) {
        for (var client in allData['clients'] as List) {
          final clientDoc =
              userDocRef.collection('clients').doc(client['id'].toString());
          batch.set(clientDoc, _sanitizeData(client));
        }
      }

      if (allData['credits'] != null) {
        for (var credit in allData['credits'] as List) {
          final creditDoc =
              userDocRef.collection('credits').doc(credit['id'].toString());
          batch.set(creditDoc, _sanitizeData(credit));
        }
      }

      if (allData['paiements'] != null) {
        for (var paiement in allData['paiements'] as List) {
          final paiementDoc =
              userDocRef.collection('paiements').doc(paiement['id'].toString());
          batch.set(paiementDoc, _sanitizeData(paiement));
        }
      }

      if (allData['cheques'] != null) {
        for (var cheque in allData['cheques'] as List) {
          final chequeDoc =
              userDocRef.collection('cheques').doc(cheque['id'].toString());
          batch.set(chequeDoc, _sanitizeData(cheque));
        }
      }

      if (allData['categories'] != null) {
        for (var category in allData['categories'] as List) {
          final categoryDoc = userDocRef
              .collection('categories')
              .doc(category['id'].toString());
          batch.set(categoryDoc, _sanitizeData(category));
        }
      }

      final metadataDoc = userDocRef.collection('_metadata').doc('info');
      batch.set(
        metadataDoc,
        {
          'lastBackupTime': FieldValue.serverTimestamp(),
          'appVersion': '2.0.0',
          'deviceId': _getDeviceId(),
          'tablesCount': {
            'clients': (allData['clients'] as List?)?.length ?? 0,
            'credits': (allData['credits'] as List?)?.length ?? 0,
            'paiements': (allData['paiements'] as List?)?.length ?? 0,
            'cheques': (allData['cheques'] as List?)?.length ?? 0,
            'categories': (allData['categories'] as List?)?.length ?? 0,
          },
        },
        SetOptions(merge: true),
      );

      await batch.commit();

      _isSyncing = false;
      _syncStatus = Tr.s('backup_success');
      notifyListeners();

      print('✅ Backup successful for $phoneNumber');
      return true;
    } on FirebaseException catch (e) {
      _syncStatus = _mapFirebaseError(e);
      _isSyncing = false;
      notifyListeners();
      print('❌ Firebase backup error: ${e.message}');
      return false;
    } catch (e) {
      _syncStatus = '${Tr.s('backup_failed')}: ${e.toString()}';
      _isSyncing = false;
      notifyListeners();
      print('❌ Backup error: $e');
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  RESTORE (Pull from Firestore)
  // ═══════════════════════════════════════════════════════════════════════════

  Future<bool> restoreAllData(String phoneNumber) async {
    if (phoneNumber.isEmpty) {
      print('❌ RESTORE: Phone number is empty!');
      _syncStatus = 'Phone number empty';
      notifyListeners();
      return false;
    }

    print('🔍 RESTORE DEBUG: Starting restore for phone: $phoneNumber');

    try {
      _isSyncing = true;
      _syncStatus = 'جاري الاستعادة...';
      notifyListeners();

      final hasInternet = await hasInternetConnection();
      if (!hasInternet) {
        print('❌ RESTORE: No internet connection');
        final hasLocalData = await _hasLocalData();
        if (hasLocalData) {
          _syncStatus = Tr.s('offline_mode');
          _isSyncing = false;
          notifyListeners();
          return true;
        }
        _syncStatus = Tr.s('no_internet_error');
        _isSyncing = false;
        notifyListeners();
        return false;
      }
      print('✅ RESTORE: Internet OK');

      final firestore = FirebaseFirestore.instance;
      final userRef = firestore.collection('users').doc(phoneNumber);

      print('🔍 RESTORE: User ref path: ${userRef.path}');

      // شيك على clients collection مباشرة — parent doc ممكن ما يكونش موجود
      final clientsCheck = await userRef.collection('clients').limit(1).get();
      if (clientsCheck.docs.isEmpty) {
        print('⚠️ RESTORE: No clients found in Firestore - first time user');
        _syncStatus = Tr.s('no_backup_found');
        _isSyncing = false;
        notifyListeners();
        return true;
      }
      print('✅ RESTORE: Backup found in Firestore');

      final data = <String, List<Map<String, dynamic>>>{};
      final collections = [
        'clients',
        'credits',
        'paiements',
        'cheques',
        'categories'
      ];

      for (final collName in collections) {
        print('🔍 RESTORE: Downloading $collName...');
        try {
          final docs = await userRef.collection(collName).get();
          print('✅ RESTORE: $collName found ${docs.docs.length} documents');

          data[collName] = docs.docs.map((doc) {
            final map = Map<String, dynamic>.from(doc.data());

            // تحويل integer fields
            for (final key in ['id', 'clientId', 'creditId', 'categoryId']) {
              if (map[key] != null) {
                map[key] = int.tryParse(map[key].toString()) ?? map[key];
              }
            }

            // تحويل double fields
            for (final key in [
              'montantTotal',
              'montantRestant',
              'montant',
              'solde'
            ]) {
              if (map[key] != null) {
                map[key] = (map[key] as num).toDouble();
              }
            }

            return map;
          }).toList();
        } catch (e) {
          print('❌ RESTORE: Error downloading $collName: $e');
        }
      }

      if (data.isEmpty) {
        print('⚠️ RESTORE: No data found in any collection');
        _syncStatus = Tr.s('no_backup_found');
        _isSyncing = false;
        notifyListeners();
        return true;
      }

      print('✅ RESTORE: All data downloaded');
      print('🔍 RESTORE: Data summary: ${data.keys.join(", ")}');
      for (final entry in data.entries) {
        print('   - ${entry.key}: ${entry.value.length} items');
      }

      print('🔍 RESTORE: Clearing local database...');
      await DatabaseHelper.instance.deleteAllData();
      print('✅ RESTORE: Local database cleared');

      print('🔍 RESTORE: Starting database import...');
      await DatabaseHelper.instance.importData(data);

      print('✅ RESTORE: Database import successful!');

      try {
        await userRef.collection('_metadata').doc('info').update({
          'lastRestoreTime': FieldValue.serverTimestamp(),
          'lastRestoredDevice': _getDeviceId(),
        });
      } catch (e) {
        print('⚠️ Could not update restore metadata: $e');
      }

      _syncStatus = Tr.s('restore_success');
      _isSyncing = false;
      notifyListeners();
      return true;
    } on FirebaseException catch (e) {
      print('❌ RESTORE FIREBASE ERROR: ${e.message}');
      print('❌ RESTORE ERROR CODE: ${e.code}');
      final errorMsg = _mapFirebaseError(e);
      _syncStatus = errorMsg;
      _isSyncing = false;
      notifyListeners();
      return false;
    } catch (e) {
      print('❌ RESTORE ERROR: $e');
      print('❌ RESTORE ERROR TYPE: ${e.runtimeType}');
      _syncStatus = '${Tr.s('restore_failed')}: ${e.toString()}';
      _isSyncing = false;
      notifyListeners();
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  CHECK & FETCH
  // ═══════════════════════════════════════════════════════════════════════════

  Future<bool> backupExistsForPhone(String phoneNumber) async {
    if (!await hasInternetConnection()) return false;

    try {
      final userDocRef = _fs.collection('users').doc(phoneNumber);
      final snapshot = await userDocRef.get();
      return snapshot.exists;
    } catch (e) {
      print('❌ Error checking backup existence: $e');
      return false;
    }
  }

  Future<DateTime?> getLastBackupTime(String phoneNumber) async {
    if (!await hasInternetConnection()) return null;

    try {
      final metadataDoc = await _fs
          .collection('users')
          .doc(phoneNumber)
          .collection('_metadata')
          .doc('info')
          .get();

      if (metadataDoc.exists) {
        final timestamp = metadataDoc['lastBackupTime'] as Timestamp?;
        return timestamp?.toDate();
      }
      return null;
    } catch (e) {
      print('❌ Error fetching last backup time: $e');
      return null;
    }
  }

  Future<Map<String, int>> getBackupStats(String phoneNumber) async {
    if (!await hasInternetConnection()) return {};

    try {
      final metadataDoc = await _fs
          .collection('users')
          .doc(phoneNumber)
          .collection('_metadata')
          .doc('info')
          .get();

      if (metadataDoc.exists) {
        final tablesCount = metadataDoc['tablesCount'] as Map<String, dynamic>?;
        if (tablesCount != null) {
          return tablesCount.cast<String, int>();
        }
      }
      return {};
    } catch (e) {
      print('❌ Error fetching backup stats: $e');
      return {};
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  CONNECTIVITY CHECK
  // ═══════════════════════════════════════════════════════════════════════════

  Future<bool> hasInternetConnection() async {
    try {
      final result = await _connectivity.checkConnectivity();
      return result != ConnectivityResult.none;
    } catch (e) {
      print('❌ Error checking connectivity: $e');
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  //  PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════════════════════

  Map<String, dynamic> _sanitizeData(Map<String, dynamic> data) {
    final sanitized = <String, dynamic>{};
    data.forEach((key, value) {
      if (value == null) return;
      sanitized[key] = value;
    });
    return sanitized;
  }

  Future<bool> _hasLocalData() async {
    try {
      final clients = await DatabaseHelper.instance.getAllClients();
      return clients.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  String _getDeviceId() {
    return DateTime.now().millisecondsSinceEpoch.toString();
  }

  String _mapFirebaseError(FirebaseException e) {
    switch (e.code) {
      case 'permission-denied':
        return Tr.s('error_permission_denied');
      case 'not-found':
        return Tr.s('no_backup_found');
      case 'unavailable':
        return Tr.s('firebase_unavailable');
      case 'network-error':
        return Tr.s('no_internet_error');
      default:
        return '${Tr.s('sync_error')}: ${e.code}';
    }
  }

  Future<bool> incrementalSync(String phoneNumber) async {
    return backupAllData(phoneNumber);
  }

  Future<bool> deleteBackupForPhone(String phoneNumber) async {
    if (!await hasInternetConnection()) {
      _syncStatus = Tr.s('no_internet_error');
      notifyListeners();
      return false;
    }

    try {
      final userDocRef = _fs.collection('users').doc(phoneNumber);
      final collections = [
        'clients',
        'credits',
        'paiements',
        'cheques',
        'categories',
        '_metadata'
      ];

      for (final collectionName in collections) {
        final snapshot = await userDocRef.collection(collectionName).get();
        for (final doc in snapshot.docs) {
          await doc.reference.delete();
        }
      }

      await userDocRef.delete();

      _syncStatus = Tr.s('backup_deleted');
      notifyListeners();

      print('✅ Backup deleted for $phoneNumber');
      return true;
    } catch (e) {
      _syncStatus = '${Tr.s('delete_failed')}: ${e.toString()}';
      notifyListeners();
      print('❌ Error deleting backup: $e');
      return false;
    }
  }
}